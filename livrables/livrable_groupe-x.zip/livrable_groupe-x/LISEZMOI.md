# Livrable — groupe-x

Modèle de base : `Qwen/Qwen3-0.6B` (révision `c1899de289a04d12100db370d81485cdf75e47ca`)
Adaptateur LoRA : `adaptateur/` (2.3 Mo, float16)
Run MLflow : `lora 150 pas` (a5ca9833a44d452d9e731739c8f4f1b1)

| mesure | validation | test |
|---|---|---|
| intent_acc (LoRA) | 79% | 71% |
| exact (LoRA) | 46% | 42% |
| intent_acc (base+prompt) | — | 67% |

Porte de qualité : FAIL
Lectures du test pendant le projet : 1
Notes du groupe : aucune

Pour évaluer ce livrable (le modèle de base est téléchargé automatiquement) :

    uv run python evaluer_livrable.py livrable_groupe-x.zip
    uv run python evaluer_livrable.py livrable_groupe-x.zip --demo
